self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "de12b1b9252216b3e777fc31e525fe4b",
    "url": "./index.html"
  },
  {
    "revision": "ef82b6eaaf6249f8262c",
    "url": "./static/css/11.6bedc294.chunk.css"
  },
  {
    "revision": "9ed48963c7e8b2092db3",
    "url": "./static/css/5.de0a96ee.chunk.css"
  },
  {
    "revision": "28c3851c5b24b9920a16",
    "url": "./static/css/main.29796279.chunk.css"
  },
  {
    "revision": "5a666ff0855d2eeb89db",
    "url": "./static/js/0.054628b6.chunk.js"
  },
  {
    "revision": "ae8ff0c6064570a36a04",
    "url": "./static/js/1.cf04c885.chunk.js"
  },
  {
    "revision": "87d7ea5fc820e1820fbd",
    "url": "./static/js/10.b0faa6fa.chunk.js"
  },
  {
    "revision": "ef82b6eaaf6249f8262c",
    "url": "./static/js/11.fef6718e.chunk.js"
  },
  {
    "revision": "15b0477575057686e4c9",
    "url": "./static/js/12.5871df8d.chunk.js"
  },
  {
    "revision": "f1661a8ddc14b796a176",
    "url": "./static/js/13.bfdf8479.chunk.js"
  },
  {
    "revision": "8f67957254b146ba1b44",
    "url": "./static/js/14.48b49351.chunk.js"
  },
  {
    "revision": "77fd112149cc0afa5260",
    "url": "./static/js/15.ac20adf3.chunk.js"
  },
  {
    "revision": "11643d3e4cb386226dcf",
    "url": "./static/js/16.72a2184f.chunk.js"
  },
  {
    "revision": "90b8fa0974b29609de59",
    "url": "./static/js/17.b35e25cb.chunk.js"
  },
  {
    "revision": "5f19aff421a234e25b08",
    "url": "./static/js/18.467967a5.chunk.js"
  },
  {
    "revision": "b1bcbda6cf23d33f5974",
    "url": "./static/js/19.89abdc5a.chunk.js"
  },
  {
    "revision": "976e2afeb4c636b2d165",
    "url": "./static/js/20.b9aa6192.chunk.js"
  },
  {
    "revision": "9ed48963c7e8b2092db3",
    "url": "./static/js/5.938533d6.chunk.js"
  },
  {
    "revision": "d823b32ac834a5ffda56",
    "url": "./static/js/6.627f9f76.chunk.js"
  },
  {
    "revision": "aa0eabdde57c979624f6",
    "url": "./static/js/7.46f6ed31.chunk.js"
  },
  {
    "revision": "8ba3b7b8281ac487023a",
    "url": "./static/js/8.820dca14.chunk.js"
  },
  {
    "revision": "64d5d04a8a7736e14525",
    "url": "./static/js/9.2e5d8c74.chunk.js"
  },
  {
    "revision": "38b7f0c2f4d9982c5de0",
    "url": "./static/js/ipld.2d955411.chunk.js"
  },
  {
    "revision": "28c3851c5b24b9920a16",
    "url": "./static/js/main.b4d56c3f.chunk.js"
  },
  {
    "revision": "693a6a1a7e232ee0e8fc",
    "url": "./static/js/runtime-main.6766f999.js"
  },
  {
    "revision": "c72d8321b8fcfde8a1ee10c2aa58a2e7",
    "url": "./static/media/Inter-UI-Bold.c72d8321.woff2"
  },
  {
    "revision": "fb221ed44be9484b9ae41ef16347da7c",
    "url": "./static/media/Inter-UI-BoldItalic.fb221ed4.woff2"
  },
  {
    "revision": "33d3b6eed8fac5511b01b36a50464334",
    "url": "./static/media/Inter-UI-Italic.33d3b6ee.woff2"
  },
  {
    "revision": "0159e50e63f10ef639c6211d80cd2e89",
    "url": "./static/media/Inter-UI-Medium.0159e50e.woff2"
  },
  {
    "revision": "786fa10d111e2e550bd6a8cf01fe2e2b",
    "url": "./static/media/Inter-UI-MediumItalic.786fa10d.woff2"
  },
  {
    "revision": "2ac4e7b8520cba23b08618aed264b056",
    "url": "./static/media/Inter-UI-Regular.2ac4e7b8.woff2"
  },
  {
    "revision": "48d9a2cc39bc60ea3f87e8348b2a17e1",
    "url": "./static/media/Montserrat-Bold.48d9a2cc.woff2"
  },
  {
    "revision": "4e7ad891b89cc53655a7b2b4845fab43",
    "url": "./static/media/Montserrat-BoldItalic.4e7ad891.woff2"
  },
  {
    "revision": "940e32eb055d675e57c51f3b6879fdd7",
    "url": "./static/media/Montserrat-Italic.940e32eb.woff2"
  },
  {
    "revision": "ee3ac7e480c3c83887f3b50d02656dc0",
    "url": "./static/media/Montserrat-Light.ee3ac7e4.woff2"
  },
  {
    "revision": "515eeaf8b22c193a82e30586b2fda0ae",
    "url": "./static/media/Montserrat-LightItalic.515eeaf8.woff2"
  },
  {
    "revision": "c38a9d8c4a647eadd860c2893c682d2b",
    "url": "./static/media/Montserrat-Regular.c38a9d8c.woff2"
  },
  {
    "revision": "b4f9714141878f10bbf0b8ab6e143717",
    "url": "./static/media/Montserrat-SemiBold.b4f97141.woff2"
  },
  {
    "revision": "9282e5ff8bdd6ef6d861363d0a8e5d7c",
    "url": "./static/media/Montserrat-SemiBoldItalic.9282e5ff.woff2"
  },
  {
    "revision": "5cd62256716efbad5410be4a478af940",
    "url": "./static/media/StaticMap.5cd62256.svg"
  },
  {
    "revision": "4831bd1a6c452f98d50033750a63e308",
    "url": "./static/media/ipfs-logo-text.4831bd1a.svg"
  },
  {
    "revision": "e2de4d07495803d921dcf272b11883ae",
    "url": "./static/media/ipfs-logo.e2de4d07.svg"
  },
  {
    "revision": "99b4bfac3f8dcf4b47e71e83789c5b6d",
    "url": "./static/media/ipld.99b4bfac.svg"
  }
]);