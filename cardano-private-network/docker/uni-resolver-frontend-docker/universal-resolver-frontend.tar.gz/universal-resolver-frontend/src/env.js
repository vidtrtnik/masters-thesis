window._env_ = {
  backendUrl: "https://dev.uniresolver.io/"
}