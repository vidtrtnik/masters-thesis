window._env_ = {
  backendUrl: "${BACKEND_URL}"
}