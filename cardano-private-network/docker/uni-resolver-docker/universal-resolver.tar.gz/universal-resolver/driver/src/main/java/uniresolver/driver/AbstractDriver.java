package uniresolver.driver;

public abstract class AbstractDriver implements Driver {

}
